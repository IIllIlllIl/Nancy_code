def make_a_pile(n):
    
    return [n + 2*i for i in range(n)]
assert make_a_pile(2) == [2, 4]
